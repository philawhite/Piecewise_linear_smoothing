library(tidyverse)
library(geosphere)
library(MCMCpack)
library(emulator)
library(MASS)
library(Matrix)
library(splines)
library(boot)
rm(list = ls())

###### ###### ###### ###### ###### ###### 
###### ###### ###### ###### ###### ###### 
###### Functions Used in MCMC
###### ###### ###### ###### ###### ######
###### ###### ###### ###### ###### ###### 

###### ###### ###### Transformed critical density

gen_logit = function(x,lims){
  log((x - lims[1])/(lims[2] - x))
}


gen_logit_all = function(x,lims = rho_lims){
  log((x - lims[,1])/(lims[,2] - x))
}

###### ###### ###### transform back to critical density


inv_logit = function(x,lims){
  lims[1] + (lims[2] - lims[1])/ ( 1 + exp(-x))
}



inv_logit_all = function(x,lims = rho_lims){
  lims[,1] + (lims[,2] - lims[,1]) / (1 + exp(-x))
}


###### ###### ###### Find critical depths corresponding to critical densities

crit_depth_func = function(alp,k,rho,SMB){
  
  log_rho1 = log(rho[1] / (rho_i - rho[1]))
  log_rho2 = log(rho[2] / (rho_i - rho[2]))
  log_rho3 = log(rho[3] / (rho_i - rho[3]))
  
  kap1 = (log_rho1 - alp) / (rho_i * k[1])
  kap2 = kap1 + sqrt(SMB) * (log_rho2 - log_rho1) / (rho_i * k[2])
  kap3 = kap2 + sqrt(SMB) * (log_rho3 - log_rho2) / (rho_i * k[3])
  
  c(kap1,kap2,kap3)
  
}


###### ###### ###### Calculate projection


proj_func = function(X){
  X_use = as.matrix(X[,apply(X,2,function(q){any(q != 0)})])
  diag(nrow(X_use)) -  quad.tform(solve(crossprod(X_use) + 1e-3 * diag(ncol(X_use))),X_use) 
}

###### ###### ###### Difference in prior distribution for spline pars, changing one component


metro_my_dmvnorm = function(ind,cand,w_old,w_old_other,sigma2,prec){
  (( w_old^2 - cand^2)*prec[ind] + sum( 2*(w_old - cand)*( w_old_other * prec[-ind]) ) ) / (2*sigma2)
}

###### ###### ###### matrix normal


dmatnorm = function(X,mu,U_inv,V_inv,log_det_U,log_det_V){
  n = nrow(X)
  p = ncol(X)
  X_scale = sweep(X,2,mu,"-")
  left = V_inv %*% t(X_scale)
  right = U_inv %*% X_scale
  -n * p * log(2 * pi) / 2  - n/2 * log_det_V - p/2 * log_det_U - 1/2 * sum(diag(left %*% right))
}


########## My multivariate normal

my_dmvnorm = function(Y,sigma2,log_det,prec){
  n_local = length(Y) 
  -n_local/2 * log(2 * pi) - 
    1/2 * (log_det + n_local * log(sigma2)) - 
    quad.form(prec,Y) / (2 * sigma2)
}

###### ###### ###### truncated t likelihood

likelihood = function(y,mu,mod_var,df_par){
  
  out = sum(dt((y - mu) / mod_var,df = df_par,log = TRUE) - 
              log(mod_var) - pt((0 - mu) / mod_var,df = df_par,lower.tail = FALSE,log.p = TRUE))
  out
  
}

###### ###### ###### truncated t likelihood


z_func = function(depth, cutoff,smb){
  
  rho_i * cbind(
    ifelse(depth < cutoff[1], depth,cutoff[1] ),
    ifelse(depth < cutoff[2], depth - cutoff[1],
           cutoff[2] - cutoff[1]) * (depth > cutoff[1]) / sqrt(smb),
    ifelse(depth < cutoff[3], depth - cutoff[2],
           cutoff[3] - cutoff[2]) * (depth > cutoff[2]) / sqrt(smb),
    (depth - cutoff[3]) * (depth > cutoff[3]) / sqrt(smb)
  )
  
}


###### Load in previous MCMC to help choose first proposal distributions
###### As well as, good starting values

# load("weighted_sites_t2.RData")  # this is used to create prio
# 
# #### CAndidate covariances -- Use previous workspace parameters
# 
# chol_s <- temp_s <- cand_var_s <- vector(mode = "list", length = n_u)
# 
# ### not the recommended scale factor.
# ### aiming for more acceptances early in the MCMC
# 
# scale_fac = rep(2.38^2 / n_u,n_u)
# 
# for(i in 1:n_u){
#   
#   temp_s[[i]] = cov(unique(spat_pars[-(1:burn),i,]))
#   cand_var_s[[i]] = scale_fac[i] * temp_s[[i]]
#   chol_s[[i]] = t(chol(cand_var_s[[i]]))
#   
# }
# 
# save(temp_s,cand_var_s,chol_s,alp_now,log_A_now,log_E_now,
#      logit_rho_now,tau2_now,log_tau2_now,hier_eta_now,
#      sig2_now,df_now,phi_now,V_now,pars_now,crit_depth,
#      mod_var, cand_sig_phi, cand_sig_df, cand_sig_tau,cand_sig_eta,
#      file = "previous_pars.RData")


load("previous_pars.RData") 


###### ###### ###### ###### ###### ###### 
###### Load in data
###### ###### ###### ###### ###### ###### 

dat = readRDS("densities.rds")

###### Load in posterior mean temperature and smb

core_temp = read.csv("core_temperature.csv")

###### Expeditions. We don't use WDC core. 

dat$meas_group = c(rep("EAP",3),
                   rep("SDM",7),
                   rep("SEAT",14),
                   rep("US",33),"WDC")

dat$meas_num = as.numeric(factor(dat$meas_group)) 
n_type = length(unique(dat$meas_num)) - 1

###### Get number of stage, critical densities, and arrhenius pars

nx = 4
n_rho = nx - 1
n_par = n_rho + 2 * nx + 1

###### number of cores

dat$core = 1:nrow(dat)

###### Location index to capture duplicate

dat$loc_ind = c(1:25,25:57)
dat$loc_ind[25] = 11

###### Exclude WDC core

dat = dat[1:57,]



ns = nrow(dat)  ###### number of cores (57)

######  Create the dataset we use

for(i in 1:ns){
  colnames(dat$Data.rho[[i]]) = c("Depth","Density")
} 


depth_dens_data =bind_rows(dat$Data.rho, .id = "core")[,1:3]

depth_dens_data$core = as.factor(as.numeric(depth_dens_data$core))

####### number of obs for each core

ni = table(depth_dens_data$core) 

####### maximum depth

max_depth = tapply(depth_dens_data$Depth,depth_dens_data$core,max) 

####### dx for each core

dx = max_depth / ni  

####### core_indx

core_unique = c(1:ns)

####### create dataset

dat_use = depth_dens_data[depth_dens_data$core %in% core_unique,1:3]
dat_use$lat = dat$Lat[unique(dat_use$core)][dat_use$core]
dat_use$lon = dat$Lon[unique(dat_use$core)][dat_use$core]
dat_use = dat_use[complete.cases(dat_use),]
n = nrow(dat_use)  

####### core and location index


locs_unique = unique(dat_use[,c("lon","lat")])
n_u = nrow(locs_unique)
rownames(locs_unique) = 1:n_u


for(i in 1:ns){
  dat_use$core[dat_use$core == core_unique[i] ] = i
}
dat_use$core = as.factor(as.numeric(dat_use$core))


dat_use$loc_ind = numeric(nrow(dat_use))

for(i in 1:n_u){
  dat_use$loc_ind[dat_use$lon == locs_unique$lon[i]] = i
}

rownames(locs_unique) = 1:n_u

dd = distm(locs_unique,fun = distCosine) / 1000  ##distance matix in km


##### make y variable for easier coding

y = dat_use$Density

##### Measurement index and count per expedition

meas_core_ind = lapply(1:n_type,function(i){which(dat$meas_num== i)})
n_meas = sapply(meas_core_ind,length)

##### link cores to loc indices

core_loc_ind = lapply(1:n_u,function(i){which(dat$loc_ind == i)})
core_loc_ind_length = sapply(1:n_u,function(i){sum(dat$loc_ind == i)})


#### CAndidate variances -- commented lines kept from previous workspace

# cand_sig_phi = rep(1e-4,n_par)
# cand_sig_df = 1e-2
# cand_sig_tau = rep(1e-2,ns)
# cand_sig_eta = rep(1e-4,ns)

cand_sig_phi_poly = 1e-3   ### previous model doesn't have smooth component
count_phi_poly = 0



################################################
#### MCMC Settings
################################################

reps = 200000      #### post-burn iterations
burn = 50000       #### burn-in iterations
tune = 100         #### scale candidate variances every ____ iterations
var_tune = 2000    #### Calculate empirical covariance evey _____ iterations
resamp = 5         #### Resample spatial parameters this many times

#### #### #### #### #### #### #### 
#### Priors for hierarchical mean parameters
#### #### #### #### #### #### #### 
Sb_inv = solve(diag(c(c(0.5,0.2,0.2,0.2,0.25)^2,1,1,1)))
mb = c(-0.5,2.4,6.35,9.23,9.97,0,0,0)
sb_inv_mean = Sb_inv %*% mb

#### #### Limits on critical density
rho_lims = matrix(c(.42,.68,.78,.68,.78,.88),ncol = 2)

################################
#### hier_avg_mat is the M^T matrix 
################################

hier_avg_mat = matrix(0,n_par - 4,n_par)
hier_avg_mat[1,1] = 1; hier_avg_mat[2,2] = 1
hier_avg_mat[3,3:5] = 1; hier_avg_mat[4,6] = 1
hier_avg_mat[5,7:9] = 1; hier_avg_mat[6,10] = 1
hier_avg_mat[7,11] = 1; hier_avg_mat[8,12] = 1

################################
#### Physical constants
################################

R_const = 8.314 ## ideal gas const
rho_i = 0.917   ## density of ice


################################
#### storage for parameters
################################


#### Hierarchical parameters
#### If commented out, we used previous workspace as starting point

alp = numeric(reps + burn); #alp_now = log(0.4 / (rho_i - 0.4))
log_A = matrix(0,reps + burn, nx); #log_A_now = log(c(11,575,575,575))
log_E = matrix(0,reps + burn, nx); #log_E_now = log(c(10160,21400,21400,21400))
logit_rho_crit = matrix(0,reps + burn,n_rho); 
#logit_rho_now = gen_logit_all(c(.55,.73,.83),rho_lims)

tau2 = matrix(0.01,reps + burn,ns); # tau2_now = rep(tau2_now,ns)
#eta = matrix(0,reps + burn,ns); eta_now = rep(0,ns)

log_tau2 = matrix(0.01,reps + burn,n_type); #log_tau2_now = rep(mean(log(tau2_now)),n_type)
hier_eta = matrix(0,reps + burn,n_type); #hier_eta_now = c(0,-8,0,-8,0)

sig2 = numeric(reps + burn); #sig2_now = 1
df_par = numeric(reps + burn); #df_now  = 10

phi = numeric(reps + burn);  #phi_now = ifelse(phi_now > 1/30, 1/33, phi_now)
V = array(0,c(reps + burn,n_par,n_par)); # V_now = diag(V_now)

spat_pars = array(0,c(reps + burn,n_u,n_par),
                  dimnames = list(1:(reps + burn),
                                  1:n_u,
                                  c("alp", paste("logA",1:4,sep = ""), 
                                    paste("logE",1:4,sep = ""), 
                                    paste("logit_rho",1:3,sep = ""))))

#A = matrix(0,reps + burn, nx); A_now = exp(log_A_now)
#E = matrix(0,reps + burn, nx); E_now = exp(log_E_now)
#rho_crit = matrix(0,reps + burn,n_rho); 
#rho_now = inv_logit_all(logit_rho_now,rho_lims)

#### Spatial parameters  -- pars_now in loaded workspace

#alp_s_now = rnorm(n_u,alp_now,0.01)
#log_A_s_now = matrix(rep(log_A_now,n_u),ncol = nx, byrow = T)
#log_E_s_now = matrix(rep(log_E_now,n_u),ncol = nx, byrow = T)
#logit_rho_s_now = matrix(rep(logit_rho_now,n_u),ncol = n_rho, byrow = T)


alp_s_now = pars_now[,1]
log_A_s_now = pars_now[,2:5]
log_E_s_now = pars_now[,6:9]
logit_rho_s_now = pars_now[,10:12]
A_s_now = exp(log_A_s_now)
E_s_now = exp(log_E_s_now)

rho_s_now = t(apply(pars_now[,10:12],1,inv_logit_all))

k_now = t(sapply(1:n_u, function(x){
  exp(pars_now[x,2:5]- exp(pars_now[x,6:9]) / (R_const * core_temp$temp10[x]))
}))

alp_s_now = pars_now[,1]

#### Critical depth

crit_depth_temp = crit_depth
crit_depth = matrix(0, nrow = n_u, ncol = n_rho, byrow = T)

for(i in 1:n_u){
  crit_depth[i,] = crit_depth_func(alp_s_now[i],k_now[i,],
                                   rho_s_now[i,],core_temp$smb[i])
}

############################################################
#### Spatial Correlation matrix for arrhenius pars
############################################################

R = exp(- phi_now * dd)
cholR = chol(R)
R_inv = chol2inv(cholR)
log_det_R = 2 * sum(log(diag(cholR)))
R_row_sum = apply(R_inv,1,sum)
R_quad_form = sum(R_inv)

############################################################
#### Between parameter covariance matrix for arrhenius pars
#### V_now loaded in from previous workspace
############################################################

cholV = chol(V_now)
V_inv = chol2inv(cholV)
log_det_V =  2 * sum(log(diag(cholV)))


################## make Z matrix -- we call this X
################## make h matrix -- we call this Z 

Z_raw <- Z <- proj_X <- X <- depth_list <- y_list <- vector(mode = "list", length = ns)

################## Quadratic spline with two knots

Z_all_raw = bs(dat_use$Depth,degree = 2,knots = c(10,30))

for(i in 1:ns){
  
  depth_list[[i]] = dat_use$Depth[dat_use$core == i]
  
  Z_raw[[i]] = Z_all_raw[which(dat_use$core == i),]
  
  y_list[[i]] = dat_use$Density[dat_use$core == i]
  
  X[[i]] = z_func(depth_list[[i]],crit_depth[dat$loc_ind[i],],
                  core_temp$smb[dat$loc_ind[i]])
  
  proj_X[[i]] = proj_func(X[[i]])
  
  Z[[i]] = proj_X[[i]] %*% Z_raw[[i]]
}

################## Parameters for quadratic spline

n_smooth = ncol(Z[[1]])

phi_poly = numeric(reps + burn); 
phi_poly_now = 1 / 500
sig2_poly = matrix(1/10,reps + burn,n_smooth); sig2_poly_now = rep(1 / 10,n_smooth)

R_poly =  exp(- phi_poly_now * dd)
cholR_poly = chol(R_poly)
R_inv_poly = chol2inv(cholR_poly)
log_det_R_poly =  2 * sum(log(diag(cholR_poly)))

bet_poly = array(0,c(reps + burn,n_u,n_smooth)); bet_poly_now = matrix(rnorm(n_u*n_smooth,0,0.01),n_u,n_smooth)

cand_var_poly = matrix(0.1,n_u,n_smooth)

################## MCMC counts

count = numeric(n_u)
count_tau = numeric(ns)
count_poly = matrix(0,n_u,n_smooth)

count_phi = 0
count_df = 0

################## Initial values


alp[1] = alp_now
log_A[1,] = log_A_now
log_E[1,] = log_E_now
logit_rho_crit[1,] = logit_rho_now

tau2[1,] = tau2_now
spat_pars[1,,] = pars_now
phi[1] = phi_now
V[1,,] = V_now

################## current mean

mu_now = lapply(1:ns,function(k){
  
  
  c(rho_i * inv.logit(alp_s_now[dat$loc_ind[k]] + 
                        X[[k]] %*% k_now[dat$loc_ind[k],] + 
                        Z[[k]] %*% bet_poly_now[dat$loc_ind[k],]))
  
})


################## log-likelihood

#### Error Model parameters
log_lik = numeric(reps + burn)
log_lik[1] = sum(sapply(1:ns,function(k){
  likelihood(y_list[[k]],mu_now[[k]],sqrt(mod_var[k]),df_now)
}))



st = proc.time()

for(i in 2:(reps + burn)){
  
  
  ############## Compute mean with current parameters
  
  mu_now = lapply(1:ns,function(k){
    
    c(rho_i * inv.logit(alp_s_now[dat$loc_ind[k]] + 
                          X[[k]] %*% k_now[dat$loc_ind[k],] + 
                          Z[[k]] %*% bet_poly_now[dat$loc_ind[k],]))
    
  })
  
  ############## Current spatial and hierarchical pars
  
  
  pars_now = cbind(alp_s_now,log_A_s_now,log_E_s_now,logit_rho_s_now)
  mu_tot = c(alp_now,log_A_now,log_E_now,logit_rho_now)
  
  ############## Update variance parameters for each site
  
  for(j in 1:ns){
    
    cand = rlnorm(1,log(tau2_now[j]),cand_sig_tau[j])  
    
    
    MH_dif = dlnorm(tau2_now[j],log(cand),cand_sig_tau[j],log = TRUE) - 
      dlnorm(cand,log(tau2_now[j]),cand_sig_tau[j],log = TRUE)
    
    like_now = likelihood(y_list[[j]],mu_now[[j]],sqrt(tau2_now[j] ),df_now)
    
    like_cand = likelihood(y_list[[j]],mu_now[[j]],sqrt(cand ),df_now)
    
    prior_mean = log_tau2_now[dat$meas_num[j]] + 
      hier_eta_now[dat$meas_num[j]] * log(dx[j])
    
    prior_dif = dnorm(log(cand), prior_mean,sqrt(sig2_now),log = TRUE ) - 
      dnorm(log(tau2_now[j]), prior_mean,sqrt(sig2_now),log = TRUE )
    
    
    if(like_cand - like_now + prior_dif + MH_dif > log(runif(1))){
      
      tau2_now[j] = cand
      count_tau[j] = count_tau[j] + 1
      mod_var[j] =  tau2_now[j]
    }
    
    
    
  }
  
  ############## Update dfs for t distribution
  
  cand = rnorm(1,df_now,cand_sig_df)
  
  if(cand > 4){
    
    like_now = sum(sapply(1:ns,function(k){
      likelihood(y_list[[k]],mu_now[[k]],sqrt(mod_var[k]),df_now)
    }))
    
    like_cand = sum(sapply(1:ns,function(k){
      likelihood(y_list[[k]],mu_now[[k]],sqrt(mod_var[k]),cand)
    }))
    
    
    if(like_cand - like_now > log(runif(1))){
      df_now = cand
      count_df = count_df + 1 
    }
    
    
  }
  
  ############## Update hierarchical variance parameters
  
  for(j in 1:n_type){
    
    
    ######## log_tau2 by expedition
    
    v_now = 1 / (1 / 4 +  n_meas[j] / sig2_now)
    m_now = -7 / 4 +  sum(log(tau2_now[meas_core_ind[[j]]]) - 
                            hier_eta_now[j] * log(dx[meas_core_ind[[j]]]) )/ sig2_now
    
    
    log_tau2_now[j] = rnorm(1, v_now * m_now, sqrt(v_now))
    
    ######## eta by expedition
    
    
    if(j %in% c(2,4)){
      
      v_now = 1 / (1 / 4 +  sum(log(dx[meas_core_ind[[j]]])^2) / sig2_now)
      
      
      m_now = -8 / 4 + sum(log(dx[meas_core_ind[[j]]]) * 
                             (log(tau2_now[meas_core_ind[[j]]]) - log_tau2_now[j])) / sig2_now
      
      hier_eta_now[j] = rnorm(1, v_now * m_now, sqrt(v_now))
      
    }
    
  }
  
  ######## update sigma_t^2 -- hierarchical variance of log_tau
  
  
  
  a_sig = 2.1 + ns/2 
  b_sig = 1/10 + 0.5 * sum((log(tau2_now) - log_tau2_now[dat$meas_num] - 
                              hier_eta_now[dat$meas_num] * log(dx) )^2)
  sig2_now = 1 / rgamma(1,a_sig,b_sig)
  
  
  ############## Update spatial correlation par
  
  
  cand = rlnorm(1, log(phi_now), cand_sig_phi)
  
  if(cand > 1/1000 & cand < 1/10){
    
    R_cand = exp(-cand * dd)
    cholR_cand = chol(R_cand)
    R_inv_cand = chol2inv(cholR_cand)
    log_det_R_cand = 2 * sum(log(diag(cholR_cand)))
    
    prior_dif = dmatnorm(pars_now ,mu_tot,R_inv_cand,V_inv,log_det_R_cand,log_det_V) -
      dmatnorm(pars_now, mu_tot,R_inv,V_inv,log_det_R,log_det_V) 
    
    MH_dif = dlnorm(phi_now,log(cand),cand_sig_phi,log = TRUE) - 
      dlnorm(cand,log(phi_now),cand_sig_phi,log = TRUE)
    
    if(prior_dif + MH_dif > log(runif(1))){
      phi_now = cand
      R = R_cand
      cholR = cholR_cand
      R_inv = R_inv_cand
      R_row_sum = apply(R_inv,1,sum)
      R_quad_form = sum(R_inv)
      log_det_R = log_det_R_cand
      count_phi = count_phi + 1
    }
  }
  
  ############## Update between parameter correlation
  
  
  nu_new = n_par + 1 + n_u
  cov_new = diag(n_par) + quad.form(R_inv,sweep(pars_now,2,mu_tot,"-"))
  V_now = riwish(nu_new,cov_new)
  cholV = chol(V_now)
  V_inv = chol2inv(cholV)
  log_det_V =  2 * sum(log(diag(cholV)))
  
  ############## Update spatial Arrhenius parameters
  
  for(m in 1:resamp){
    
    for(j in 1:n_u){
      
      pars_now = cbind(alp_s_now,log_A_s_now,log_E_s_now,logit_rho_s_now)
      pars_cand = pars_now
      
      prev_par = pars_now[j,]
      cand = c(prev_par + chol_s[[j]] %*% rnorm(n_par))
      pars_cand[j,] = cand
      
      k_cand = exp(cand[2:5] - exp(cand[6:9])/ (R_const * core_temp$temp10[j]))
      rho_cand = inv_logit_all(cand[10:12],rho_lims)
      crit_depth_cand = crit_depth_func(cand[1],k_cand,rho_cand,core_temp$smb[j])
      
      
      if( all(dx[core_loc_ind[[j]]] < min(diff(crit_depth_cand)) ) ){
        
        X_cand = lapply(core_loc_ind[[j]],function(k){
          z_func(depth_list[[k]],crit_depth_cand,core_temp$smb[j])
        })
        
        
        proj_X_cand = lapply(X_cand, proj_func)
        
        Z_cand = lapply(1:core_loc_ind_length[j],function(k){
          proj_X_cand[[k]] %*% Z_raw[[core_loc_ind[[j]][k]]]
        })
        
        mu_cand = lapply(1:core_loc_ind_length[j],function(k){
          c(rho_i * inv.logit(cand[1] + X_cand[[k]] %*% k_cand + 
                                Z_cand[[k]] %*% bet_poly_now[dat$loc_ind[core_loc_ind[[j]][k]],] ))
        })
        
        
        like_now = sum(sapply(1:core_loc_ind_length[j],function(k){
          likelihood(y_list[[ core_loc_ind[[j]][k] ]],
                     mu_now[[core_loc_ind[[j]][k]]],
                     sqrt(mod_var[core_loc_ind[[j]][k]]),df_now)
          
        }))
        
        like_cand = sum(sapply(1:core_loc_ind_length[j],function(k){
          likelihood(y_list[[ core_loc_ind[[j]][k] ]],
                     mu_cand[[k]],
                     sqrt(mod_var[core_loc_ind[[j]][k]]),df_now)
          
        }))
        
        prior_dif = dmatnorm(pars_cand ,mu_tot,R_inv,V_inv,log_det_R,log_det_V) - 
          dmatnorm(pars_now,mu_tot,R_inv,V_inv,log_det_R,log_det_V)
        
        if(!is.na(like_cand)){
          if(like_cand - like_now + prior_dif > log(runif(1))){
            pars_now[j,] = cand
            alp_s_now[j] = cand[1]
            rho_s_now[j,] = rho_cand
            log_A_s_now[j,] = cand[2:5]
            log_E_s_now[j,] = cand[6:9]
            logit_rho_s_now[j,] = cand[10:12]
            crit_depth[j,] = crit_depth_cand
            
            k_now[j,] = k_cand
            
            for(k in 1:core_loc_ind_length[j]){
              X[[core_loc_ind[[j]][k]]] = X_cand[[k]]
              
              mu_now[[core_loc_ind[[j]][k]]] = mu_cand[[k]]
              
              Z[[core_loc_ind[[j]][k]]] = Z_cand[[k]]
              proj_X[[core_loc_ind[[j]][k]]] = proj_X_cand[[k]]
              
            }
            
            count[j] = count[j] + 1
          }
        }
        
      }
    }
  }
  
  ############## Update spatial spline parameters
  
  
  for(m in 1:resamp){
    
    
    for(k in 1:n_smooth){
      
      
      for(j in 1:n_u){
        
        
        bet_poly_cand = bet_poly_now
        bet_poly_cand[j,k] = rnorm(1,bet_poly_now[j,k],cand_var_poly[j,k])
        
        mu_cand = lapply(core_loc_ind[[j]],function(l){
          c(rho_i * inv.logit(alp_s_now[j] + X[[l]] %*% k_now[j,] + Z[[l]] %*% bet_poly_cand[j,] ))
        })
        
        like_now = sum(sapply(1:core_loc_ind_length[j],function(l){
          likelihood(y_list[[core_loc_ind[[j]][l]]],mu_now[[core_loc_ind[[j]][l]]],
                     sqrt(mod_var[core_loc_ind[[j]][l]]),df_now)
        }))
        
        like_cand = sum(sapply(1:core_loc_ind_length[j],function(l){
          likelihood(y_list[[ core_loc_ind[[j]][l] ]], mu_cand[[l]],
                     sqrt(mod_var[core_loc_ind[[j]][l]]),df_now)
        }))
        
        prior_dif = metro_my_dmvnorm(j,bet_poly_cand[j,k],bet_poly_now[j,k],bet_poly_cand[-j,k],
                                     sig2_poly_now[k],R_inv_poly[j,])
        
        if(like_cand - like_now + prior_dif > log(runif(1)) ){
          
          bet_poly_now = bet_poly_cand
          
          for(l in 1:core_loc_ind_length[j]){
            
            mu_now[[core_loc_ind[[j]][l]]] = mu_cand[[l]]
            
          }
          
          count_poly[j,k] = count_poly[j,k] + 1
          
        }
        
      }
      
      
      
    }
    
    
  }
  
  ############## Update spatial spline variance
  
  
  for(k in 1:n_smooth){
    
    a_now =  2.1  + n_u/2
    b_now = 1/10 +  quad.form(R_inv_poly,bet_poly_cand[,k]) / 2
    sig2_poly_now[k] = 1 / rgamma(1,a_now,b_now)
  }
  
  ############## Update spatial spline correlation parameter
  
  
  cand = rlnorm(1, log(phi_poly_now), cand_sig_phi_poly)
  
  if(cand > 1/1000 & cand < 1/10){
    
    R_cand_poly = exp(-cand * dd)
    cholR_cand_poly = chol(R_cand_poly)
    R_inv_cand_poly = chol2inv(cholR_cand_poly)
    log_det_R_cand_poly = 2 * sum(log(diag(cholR_cand_poly)))
    
    prior_dif = sum(sapply(1:n_smooth,function(k){
      my_dmvnorm(bet_poly_now[,k],sig2_poly_now[k],log_det_R_cand_poly, R_inv_cand_poly) -
        my_dmvnorm(bet_poly_now[,k],sig2_poly_now[k],log_det_R_poly, R_inv_poly)
    }))
    
    MH_dif = dlnorm(phi_poly_now,log(cand),cand_sig_phi_poly,log = TRUE) - 
      dlnorm(cand,log(phi_poly_now),cand_sig_phi_poly,log = TRUE)
    
    if(prior_dif + MH_dif > log(runif(1))){
      phi_poly_now = cand
      R_poly = R_cand_poly
      cholR_poly= cholR_cand_poly
      R_inv_poly = R_inv_cand_poly
      log_det_R_poly = log_det_R_cand_poly
      count_phi_poly = count_phi_poly + 1
    }
    
  }
  
  
  ############## Update hierarchical means for spatial Arrhenius parameters
  
  cov_part = solve(Sb_inv + R_quad_form * quad.tform(V_inv,hier_avg_mat) )
  mean_part = (sb_inv_mean +  hier_avg_mat %*%(V_inv %*% (t(pars_now) %*% R_row_sum)))
  
  mu_tot = mvrnorm(1,cov_part %*% mean_part, cov_part)
  
  alp_now = mu_tot[1]     
  log_A_now = mu_tot[c(2,3,3,3)]
  log_E_now = mu_tot[c(4,5,5,5)]
  logit_rho_now = mu_tot[c(6,7,8)]
  
  
  
  # alp_now = mu_tot[1]     
  # log_A_now = mu_tot[c(2,3,4,5)]
  # log_E_now = mu_tot[c(6,7,8,9)]
  # logit_rho_now = mu_tot[c(10,11,12)]
  
  
  ############ save current values
  
  alp[i] = alp_now
  log_A[i,] = log_A_now
  log_E[i,] = log_E_now
  logit_rho_crit[i,] = logit_rho_now
  
  tau2[i,] = tau2_now
  spat_pars[i,,] = pars_now
  phi[i] = phi_now
  
  V[i,,] = V_now
  hier_eta[i,] = hier_eta_now
  log_tau2[i,] = log_tau2_now
  sig2[i] = sig2_now
  df_par[i] = df_now
  bet_poly[i,,] = bet_poly_now
  sig2_poly[i,] = sig2_poly_now
  phi_poly[i] = phi_poly_now
  
  ############ Update between empirical covariance for multivarite update
  
  if(i %% var_tune == 0){
    
    for(j in 1:n_u){
      
      if(i > burn/2){
        temp_s[[j]] = cov(unique(spat_pars[1:i,j,]))
      } else if(i > burn){
        temp_s[[j]] = cov(unique(spat_pars[(burn/2):i,j,]))
        
      }
    }
    
  }
  
  ############ Update candidate variance
  
  
  if(i %% tune == 0){
    
    if(i < burn){
      
      ####### Calculate acceptance rates, reset counts
      
      acc_spat = count / (resamp * tune); count = rep(0,n_u)
      acc_phi = count_phi / tune ; count_phi = 0
      acc_df = count_df / tune ; count_df = 0
      acc_phi_poly = count_phi_poly / tune ; count_phi_poly = 0
      acc_tau = count_tau / tune ; count_tau = numeric(ns)
      acc_bet = count_poly / (resamp * tune) ; count_poly = matrix(0,n_u,n_smooth)
      
      ####### Update candidate variance
      
      cand_sig_phi = ifelse(acc_phi > 0.6, cand_sig_phi * 2, 
                            ifelse(acc_phi < 0.2, cand_sig_phi / 3, cand_sig_phi))
      
      cand_sig_df = ifelse(acc_df > 0.6, cand_sig_df * 2, 
                           ifelse(acc_df < 0.2, cand_sig_df / 3, cand_sig_df))
      
      cand_sig_tau = ifelse(acc_tau > 0.6, cand_sig_tau * 2, 
                            ifelse(acc_tau < 0.2, cand_sig_tau / 3, cand_sig_tau))
      
      cand_sig_phi_poly = ifelse(acc_phi_poly > 0.6, cand_sig_phi_poly * 2, 
                                 ifelse(acc_phi_poly < 0.2, cand_sig_phi_poly / 3, 
                                        cand_sig_phi_poly))
      
      
      scale_fac = ifelse(acc_spat > 0.5, scale_fac * 1.5, 
                         ifelse(acc_spat < 0.15, scale_fac / 2, scale_fac))
      
      #  scale_fac = ifelse(acc_spat < 0.05,scale_fac / 10, scale_fac)
      
      
      for(j in 1:n_u){
        for(k in 1:n_smooth){
          cand_var_poly[j,k] = ifelse(acc_bet[j,k] > 0.6, cand_var_poly[j,k] * 1.5, 
                                      ifelse(acc_bet[j,k] < 0.2, cand_var_poly[j,k] / 2, cand_var_poly[j,k]))
        }
      }
      
      
    }
    
    for(j in 1:n_u){
      cand_var_s[[j]] = scale_fac[j] * temp_s[[j]]
      chol_s[[j]] = t(chol(cand_var_s[[j]]))
    }
    
    ####### Give estimated time until completion.
    
    time_its <- (proc.time() - st)[3]  / (tune)
    time_used <- round((proc.time() - st)[3]/(60),digits=4)
    time_left <- round(time_its * (reps + burn - i )/(60),digits=4)
    cat("\r", i, " of ", reps + burn,"||| Time left: ",floor(time_left/60),
        " hours",time_left%%60," minutes |||| like = ", log_lik[i-1]) 
    flush.console()
    
    st = proc.time()
    
    
  }
  

  
  ####### Save log-likelihood
  
  
  log_lik[i] = sum(sapply(1:ns,function(k){
    likelihood(y_list[[k]],mu_now[[k]],sqrt(mod_var[k]),df_now)
  }))
  
  
}

####### Save output

#save.image("final.RData")




