library(ggplot2)
library(dplyr)
library(boot)
library(maps)
library(mapdata)
library(fields)
library(splancs)
library(mapproj)
library(Matrix)
library(parallel)
library(emulator)
library(splancs)
library(geosphere)
library(tidyverse)
library(xtable)
rm(list = ls())

inverse.stereo <- function(x,y,R=1){
  long0 = 0
  lat0 = -pi/2
  rho = sqrt( x^2 + y^2 )
  c = 2 * atan2( rho ,  2 * R )
  lat = asin( cos(c)*sin(lat0))
  long = long0 + atan2(x * sin(c), rho*cos(lat0)*cos(c) - y * sin(lat0)*sin(c) )
  res = cbind(long*180/pi,lat*180/pi)
  return(res)
}

####### ####### ####### ####### ####### ####### ####### 
####### load in final model workspace
####### ####### ####### ####### ####### ####### ####### 

load("final.RData")


####### ####### ####### ####### ####### ####### ####### 
####### get correct thinning
####### ####### ####### ####### ####### ####### ####### 


idx_use = ( burn + 1):(reps + burn)
plot(log_lik[idx_use],type = "l")
core_idx = lapply(1:57,function(x){which(dat_use$core == x)})

ni = sapply(core_idx,length)
reps_use = 10000

idx_use = idx_use[which(idx_use %% (length(idx_use) / reps_use) == 1 )]

spat_pars = spat_pars[idx_use,,]
alp = alp[idx_use]
bet_poly = bet_poly[idx_use,,]
log_A = log_A[idx_use,]
log_E = log_E[idx_use,]
logit_rho_crit = logit_rho_crit[idx_use,]
df_par = df_par[idx_use]
hier_eta = hier_eta[idx_use,]
phi = phi[idx_use]
sig2 = sig2[idx_use]
phi_poly = phi_poly[idx_use]
sig2_poly = sig2_poly[idx_use]
V = V[idx_use,,]
tau2 = tau2[idx_use,]
log_tau2 = log_tau2[idx_use,]

rm(list=setdiff(ls(), c("dat","dat_use","smb_dat","temp_dat","spat_pars","alp",
                        "bet_poly","log_A","log_E","logit_rho_crit","df_par","y_list",
                        "depth_list","core_loc_ind_length","Z_raw","mu_now","mu_cand",
                        "hier_eta","phi","sig2","phi_poly","sig2_poly","V","core_loc_ind",
                        "rho_i","rho_lims","tau2","log_tau2","R_const","core_temp",
                        "core_idx","locs_unique","dd","n_par","n_u","ns")))

save.image("final_reduced.RData")




######### load in thinned dataset

load("final_reduced.RData")


idx_use = 1:nrow(spat_pars)
reps_use = length(idx_use)

####### ####### ####### ####### ####### ####### ####### 
####### Some functions for inference
####### ####### ####### ####### ####### ####### ####### 

inv_logit_all = function(x,lims = rho_lims){
  lims[,1] + (lims[,2] - lims[,1]) / (1 + exp(-x))
}

inv_logit = function(x,lims){
  lims[1] + (lims[2] - lims[1])/ ( 1 + exp(-x))
}

####### ####### ####### ####### ####### ####### ####### 
####### Calculate posterior summaries of hierarchical parameters
####### Table 1
####### ####### ####### ####### ####### ####### ####### 

eight_pars_hier = cbind(rho_i * exp(alp[idx_use])/(1 + exp(alp[idx_use])),
                        exp(log_A[idx_use,1]),
                        exp(log_E[idx_use,1]),
                        exp(log_A[idx_use,2]),
                        exp(log_E[idx_use,2]),
                        inv_logit(logit_rho_crit[idx_use,1],rho_lims[1,]),
                        inv_logit(logit_rho_crit[idx_use,2],rho_lims[2,]),
                        inv_logit(logit_rho_crit[idx_use,3],rho_lims[3,]))


quantile_prev = c(NA,
mean(eight_pars_hier[,2] < 11),
mean(eight_pars_hier[,3] < 10160),
mean(eight_pars_hier[,4] < 575),
mean(eight_pars_hier[,5] < 21400),
mean(eight_pars_hier[,6] < 0.55),
mean(eight_pars_hier[,7] < 0.73),
mean(eight_pars_hier[,8] < 0.83))


post_sum = function(x){
  m = mean(x)
  med = median(x)
  sd = sd(x)
  ci = quantile(x,c(0.05,.95))
  c(m,med,sd,ci)
}

out = signif(t(apply(eight_pars_hier,2,post_sum)),4)

out = cbind(quantile_prev,out)
quantile_prev
colnames(out) = c("quantile","Mean","Median","Standard Deviation","5","95")
rownames(out) = c("Surface Density","A1","E1","A2","E2","rho1","rho2","rho3")
xtable(out,digits = matrix(rep(c(3,3,3,3,3,3,3,3),times = 7),ncol = 7),
       display = c("s",rep("f",6)) )


####### ####### ####### ####### ####### ####### ####### 
####### Empirical Correlation
####### Table 1
####### ####### ####### ####### ####### ####### ####### 

temp = lapply(1:10000,function(i){
  cor(spat_pars[idx_use[i],,])
})

library(reshape2)
library(ggplot2)

melted_cormat <- melt(Reduce("+", temp) / length(temp))

head(melted_cormat)


parsed = c(expression(alpha),expression(log(A[1])),expression(log(A[2])),
           expression(log(A[3])),expression(log(A[4])),
           expression(log(E[1])),expression(log(E[2])),
           expression(log(E[3])),expression(log(E[4])),
           expression(logit[1](rho[1])),expression(logit[2](rho[2])),
           expression(logit[3](rho[3])) )


# pdf("../../writing/empir_cor_mat.pdf")
ggplot(data = melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab", 
                       name="Mean\nCorrelation") +
  theme_minimal() +
  xlab("") + 
  ylab("") +
  coord_fixed() + 
 scale_x_discrete(labels= parsed)+ 
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, 
                                     size = 16, hjust = 1)) + 
  scale_y_discrete(labels= parsed)+ 
  theme(axis.text.y = element_text( vjust = 0.5, 
                                   size = 16, hjust = 1))
# dev.off()


####### ####### ####### ####### ####### ####### ####### 
####### Site-specific scale parameters
####### Figure 5
####### ####### ####### ####### ####### ####### ####### 


dat0 <- stack(as.data.frame(sqrt(tau2[idx_use,])))

dat0$group = dat$meas_group[rep(1:57,each = reps_use)]

# pdf("../../writing/core_sd.pdf",width = 10,height = 2)

ggplot(dat0) + 
  geom_violin(aes(x = ind, y = values,col = group))+ 
  labs(x = "Core", y = expression(paste(tau,"(s)")))+ 
  theme(axis.title.y = element_text(size = rel(1.8), angle = 90)) +
  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.3), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:57) 
# dev.off()

####### ####### ####### ####### ####### ####### ####### 
####### Violin plots for Site-specific parameters
####### Figure 10 - 12
####### ####### ####### ####### ####### ####### ####### 


dat1 <- stack(as.data.frame(exp(spat_pars[idx_use,,1])/(1 + exp(spat_pars[idx_use,,1])) ))
dat2 <- stack(as.data.frame(spat_pars[idx_use,,2]))
dat3 <- stack(as.data.frame(spat_pars[idx_use,,3]))
dat4 <- stack(as.data.frame(spat_pars[idx_use,,4]))
dat5 <- stack(as.data.frame(spat_pars[idx_use,,5]))
dat6 <- stack(as.data.frame(spat_pars[idx_use,,6]))
dat7 <- stack(as.data.frame(spat_pars[idx_use,,7]))
dat8 <- stack(as.data.frame(spat_pars[idx_use,,8]))
dat9 <- stack(as.data.frame(spat_pars[idx_use,,9]))
dat10 <- stack(as.data.frame(inv_logit(spat_pars[idx_use,,10],rho_lims[1,])))
dat11 <- stack(as.data.frame(inv_logit(spat_pars[idx_use,,11],rho_lims[2,])))
dat12 <- stack(as.data.frame(inv_logit(spat_pars[idx_use,,12],rho_lims[3,])))

dat1$group = dat$meas_group[rep(1:56,each = reps_use)]
dat2$group = dat$meas_group[rep(1:56,each = reps_use)]
dat3$group = dat$meas_group[rep(1:56,each = reps_use)]
dat4$group = dat$meas_group[rep(1:56,each = reps_use)]
dat5$group = dat$meas_group[rep(1:56,each = reps_use)]
dat6$group = dat$meas_group[rep(1:56,each = reps_use)]
dat7$group = dat$meas_group[rep(1:56,each = reps_use)]
dat8$group = dat$meas_group[rep(1:56,each = reps_use)]
dat9$group = dat$meas_group[rep(1:56,each = reps_use)]
dat10$group = dat$meas_group[rep(1:56,each = reps_use)]
dat11$group = dat$meas_group[rep(1:56,each = reps_use)]
dat12$group = dat$meas_group[rep(1:56,each = reps_use)]




p0 = ggplot(dat1) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste(mu,"(s,0)")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())

p1 = ggplot(dat2) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste("log[",A[1],"(s)]")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())

p2 = ggplot(dat3) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste("log[",A[2],"(s)]")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())

p3 = ggplot(dat4) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste("log[",A[3],"(s)]")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56)+ theme(axis.title.x = element_blank())

p4 = ggplot(dat5) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste("log[",A[4],"(s)]")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  # theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())


p5 = ggplot(dat6) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste("log[",E[1],"(s)]")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())

p6 = ggplot(dat7) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste("log[",E[2],"(s)]")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())

p7 = ggplot(dat8) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste("log[",E[3],"(s)]")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56)+ theme(axis.title.x = element_blank())

p8 = ggplot(dat9) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste("log[",E[4],"(s)]")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  # theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())

p9 = ggplot(dat10) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste(rho[1],"(s)")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())

p10 = ggplot(dat11) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste(rho[2],"(s)")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())

p11 = ggplot(dat12) + 
  geom_violin(aes(x = ind, y = values))+ 
  labs(x = "Site", y = expression(paste(rho[3],"(s)")))+ 
  theme(axis.title.y = element_text(size = rel(1.4), angle = 90)) +
  #  theme(axis.title.x = element_text(size = rel(1.8), angle = 00))+ 
  theme(axis.text.x = element_text(angle = 90,size = rel(1.1), hjust = 1,vjust = 1/2))+ 
  scale_x_discrete(labels=1:56) + theme(axis.title.x = element_blank())


library(gridExtra)



# pdf("../../writing/spat_dens.pdf")
grid.arrange(p0, p9, p10,p11, ncol = 1,bottom = textGrob("Site", rot = 0, vjust = 1/2,gp=gpar(fontsize=18)))
# dev.off()


# pdf("../../writing/spat_A.pdf")
grid.arrange(p1, p2,p3,p4, ncol = 1,bottom = textGrob("Site", rot = 0, vjust = 1/2,gp=gpar(fontsize=18)))
# dev.off()


# pdf("../../writing/spat_E.pdf")
grid.arrange(p5,p6, p7, p8, ncol = 1,bottom = textGrob("Site", rot = 0, vjust = 1/2,gp=gpar(fontsize=18)))
# dev.off()



####### ####### ####### ####### ####### ####### ####### 
####### spatially-varying parameter plots
####### Figure 6 and 13
####### ####### ####### ####### ####### ####### ####### 



# ni = sapply(core_idx,length)
# reps_use = 10000
# idx_use = idx_use[which(idx_use %% (length(idx_use) / reps_use) == 1 )]
# plot(log_lik[idx_use],type = "l")
# 
# projxy = mapproject(locs_unique[,1],locs_unique[,2],
#                     projection = "stereographic",
#                     orientation = c(-90,0,0))
# 
# con_hull = chull(projxy$x,projxy$y)
# poly_out = cbind(projxy$x[con_hull],projxy$y[con_hull])
# 
# griddy = gridpts(poly_out,50^2)
# 
# plot(griddy,pch = 20)
# 
# n_grid = nrow(griddy)
# 
# griddy = cbind(griddy,inverse.stereo(griddy[,1],griddy[,2]))
# colnames(griddy) = c("projx","projy","lon","lat")
# dg = distm(griddy[,3:4],locs_unique,fun = distCosine) / 1000
# gg = distm(griddy[,3:4],fun = distCosine) / 1000
# 
# 
######## This is excluded for size reasons
# load("pred_pars.RData") 
# 
# pred_median_surf = apply(rho_i * exp(pred_spat[,,1])/(1 + exp(pred_spat[,,1])),2,median)
# pred_sd_surf = apply(rho_i * exp(pred_spat[,,1])/(1 + exp(pred_spat[,,1])),2,function(x){
#   diff(quantile(x,c(.25,.75)))
# })
# 
# # pdf("../../writing/surface_density.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_surf,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#     orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#     add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/surface_density_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_surf,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#     orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#     add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# par_temp = (rho_lims[1,1] + rho_lims[1,2] * exp(pred_spat[,,10])) / (1 + exp(pred_spat[,,10]))
# 
# pred_median_crit1 = apply(par_temp,2,median)
# pred_sd_crit1 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# # pdf("../../writing/crit_dens1.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_crit1,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#     orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#     add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/crit_dens1_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_crit1,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#     orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#     add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# 
# par_temp = (rho_lims[2,1] + rho_lims[2,2] * exp(pred_spat[,,11])) / (1 + exp(pred_spat[,,11]))
# 
# pred_median_crit2 = apply(par_temp,2,median)
# pred_sd_crit2 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# # pdf("../../writing/crit_dens2.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_crit2,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#     orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#     add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/crit_dens2_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_crit2,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#     orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#     add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# 
# par_temp = (rho_lims[3,1] + rho_lims[3,2] * exp(pred_spat[,,12])) / (1 + exp(pred_spat[,,12]))
# 
# pred_median_crit3 = apply(par_temp,2,median)
# pred_sd_crit3 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# # pdf("../../writing/crit_dens3.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_crit3,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#     orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#     add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# 
# # pdf("../../writing/crit_dens3_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_crit3,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#     orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#     add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# 
# 
# par_temp = exp(pred_spat[,,2])
# 
# pred_median_A1 = apply(par_temp,2,median)
# pred_sd_A1 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# 
# par_temp = exp(pred_spat[,,6])
# 
# pred_median_E1 = apply(par_temp,2,median)
# pred_sd_E1 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# pred_temp_10 = readRDS("temperature_10_grid.rds")
# 
# temp_temp = matrix(rep(pred_temp_10,each = reps_use),nrow = reps_use)
# par_temp = exp(pred_spat[,,2]) * exp(- exp(pred_spat[,,6]) / (R_const * temp_temp) )
# 
# pred_median_k1 = apply(par_temp,2,median)
# #pred_median_k1 = ifelse(pred_temp_10 < max(core_temp$temp10),pred_median_k1,NA)
# pred_sd_k1 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# 
# par_temp = exp(pred_spat[,,3])
# 
# pred_median_A2 = apply(par_temp,2,median)
# pred_sd_A2 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# par_temp = exp(pred_spat[,,7])
# 
# pred_median_E2 = apply(par_temp,2,median)
# pred_sd_E2 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# temp_temp = matrix(rep(pred_temp_10,each = reps_use),nrow = reps_use)
# par_temp = exp(pred_spat[,,3]) * exp(- exp(pred_spat[,,7]) / (R_const * temp_temp) )
# 
# pred_median_k2 = apply(par_temp,2,median)
# #pred_median_k2 = ifelse(pred_temp_10 < max(core_temp$temp10),pred_median_k2,NA)
# pred_sd_k2 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# 
# par_temp = exp(pred_spat[,,4])
# 
# pred_median_A3 = apply(par_temp,2,median)
# pred_sd_A3 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# 
# par_temp = exp(pred_spat[,,8])
# 
# pred_median_E3 = apply(par_temp,2,median)
# pred_sd_E3 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# temp_temp = matrix(rep(pred_temp_10,each = reps_use),nrow = reps_use)
# par_temp = exp(pred_spat[,,4]) * exp(- exp(pred_spat[,,8]) / (R_const * temp_temp) )
# 
# pred_median_k3 = apply(par_temp,2,median)
# #pred_median_k2 = ifelse(pred_temp_10 < max(core_temp$temp10),pred_median_k2,NA)
# pred_sd_k3 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# 
# par_temp = exp(pred_spat[,,5])
# 
# pred_median_A4 = apply(par_temp,2,median)
# pred_sd_A4 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# par_temp = exp(pred_spat[,,9])
# 
# pred_median_E4 = apply(par_temp,2,median)
# pred_sd_E4 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
# temp_temp = matrix(rep(pred_temp_10,each = reps_use),nrow = reps_use)
# par_temp = exp(pred_spat[,,5]) * exp(- exp(pred_spat[,,9]) / (R_const * temp_temp) )
# 
# pred_median_k4 = apply(par_temp,2,median)
# #pred_median_k2 = ifelse(pred_temp_10 < max(core_temp$temp10),pred_median_k2,NA)
# pred_sd_k4 = apply(par_temp,2,function(x){   diff(quantile(x,c(.25,.75))) })
# 
# 
# 
#   
# 
# # pdf("../../writing/A1.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_A1,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/A1_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_A1,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7.5)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# zlimA234 = range(c(pred_median_A2,pred_median_A3,pred_median_A4))
# zlimE234 = range(c(pred_median_E2,pred_median_E3,pred_median_E4))
# zlimK234 = range(c(pred_median_k2,pred_median_k3,pred_median_k4))
# 
# 
# # pdf("../../writing/A2.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_A2,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimA234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# # pdf("../../writing/A2_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_A2,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# 
# # pdf("../../writing/A3.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_A3,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimA234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# # pdf("../../writing/A3_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_A3,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/A4.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_A4,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimA234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# # pdf("../../writing/A4_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_A4,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# 
# # pdf("../../writing/E1.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_E1,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7.5)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/E1_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_E1,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7.5)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# 
# 
# # pdf("../../writing/E2.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_E2,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimE234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7.5)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/E2_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_E2,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/E3.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_E3,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimE234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7.5)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/E3_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_E3,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# # pdf("../../writing/E4.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_E4,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimE234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7.5)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/E4_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_E4,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/K1.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_k1,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# # pdf("../../writing/K1_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_k1,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# 
# # pdf("../../writing/K2.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_k2,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimK234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# # pdf("../../writing/K2_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_k2,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/K3.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_k3,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimK234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# # pdf("../../writing/K3_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_k3,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/K4.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_median_k4,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = zlimK234,
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# 
# # pdf("../../writing/K4_sd.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],pred_sd_k4,nx = 60,ny = 60,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# points(projxy,pch = 20)
# # dev.off()
# # dev.off()
# 
# # pdf("../../writing/S1.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,0))
# 
# plot(0,ylim = c(0,1),xlim = c(0,1),type = "n",ann = FALSE, axes = FALSE)
# text(0.5,0.5,"First-Stage",cex = 6)
# # dev.off()
# 
# # pdf("../../writing/S2.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,0))
# 
# plot(0,ylim = c(0,1),xlim = c(0,1),type = "n",ann = FALSE, axes = FALSE)
# text(0.5,0.5,"Second-Stage",cex = 6)
# # dev.off()
# 
# 
# # pdf("../../writing/S3.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,0))
# 
# plot(0,ylim = c(0,1),xlim = c(0,1),type = "n",ann = FALSE, axes = FALSE)
# text(0.5,0.5,"Third-Stage",cex = 6)
# # dev.off()
# 
# 
# # pdf("../../writing/S4.pdf",width = 10,height = 6)
# 
# par(mar = c(0,0,0,0))
# plot(0,ylim = c(0,1),xlim = c(0,1),type = "n",ann = FALSE, axes = FALSE)
# text(0.5,0.5,"Fourth-Stage",cex = 6)
# # dev.off()
# 
# 
# 
# ####### ####### ####### ####### ####### ####### ####### 
# ####### Posterior probabilities of stage differences
# ####### Figure 7
# ####### ####### ####### ####### ####### ####### ####### 
# 
# 
# temp_temp = matrix(rep(pred_temp_10,each = reps_use),nrow = reps_use)
# par_temp2 = exp(pred_spat[,,3]) * exp(- exp(pred_spat[,,7]) / (R_const * temp_temp) )
# par_temp3 = exp(pred_spat[,,4]) * exp(- exp(pred_spat[,,8]) / (R_const * temp_temp) )
# par_temp4 = exp(pred_spat[,,5]) * exp(- exp(pred_spat[,,9]) / (R_const * temp_temp) )
# 
# n_grid = ncol(par_temp2)
# 
# prob_23 = sapply(1:n_grid,function(i){ mean(par_temp2[,i] > par_temp3[,i])})
# prob_24 = sapply(1:n_grid,function(i){ mean(par_temp2[,i] > par_temp4[,i])})
# prob_34 = sapply(1:n_grid,function(i){ mean(par_temp3[,i] > par_temp4[,i])})
# 
# 
# col_use = designer.colors( n=256, col= c("darkblue", "white", "darkred"), x=c(0,0.5,1),alpha=1)
# 
# # pdf("../../writing/prob_23.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],prob_23,nx = 60,ny = 60,col = col_use,           
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = c(0,1),
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# lines(projxy$x[c(con_hull,con_hull[1])],projxy$y[c(con_hull,con_hull[1])],lty = 3,lwd = 2)
# 
# points(projxy,pch = 20)
# 
# # dev.off()
# 
# 
# hist(prob_23)
# 
# 
# # pdf("../../writing/prob_24.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],prob_24,nx = 60,ny = 60,  col = col_use,          
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = c(0,1),
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# lines(projxy$x[c(con_hull,con_hull[1])],projxy$y[c(con_hull,con_hull[1])],lty = 3,lwd = 2)
# 
# points(projxy,pch = 20)
# 
# # dev.off()
# 
# 
# hist(prob_24)
# 
# 
# # pdf("../../writing/prob_34.pdf",width = 10,height = 6)
# par(mar = c(0,0,0,1))
# quilt.plot(griddy[,1], griddy[,2],prob_34,nx = 60,ny = 60,   col = col_use,         
#            xlim = c(min(griddy[,1] - 0.07),max(griddy[,1] + 0.01)),
#            ylim = c(min(griddy[,2] - 0.02),max(griddy[,2] + 0.01)),
#            frame.plot = FALSE,yaxt = "n",xaxt = "n",zlim = c(0,1),
#            legend.width = 2,axis.args=list(cex.axis=2),legend.mar = 7)
# maps::map(database = 'world', regions = "antarctica",proj="stereographic",
#           orientation = c(-90,0,0),xlim = range(locs_unique$lon),ylim = range(locs_unique$lat),
#           add = TRUE)
# 
# 
# lines(projxy$x[c(con_hull,con_hull[1])],projxy$y[c(con_hull,con_hull[1])],lty = 3,lwd = 2)
# points(projxy,pch = 20)
# 
# # dev.off()
# 
# hist(prob_34)

