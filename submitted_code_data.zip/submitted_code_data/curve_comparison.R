library(ggplot2)
library(dplyr)
library(boot)
library(maps)
library(mapdata)
library(fields)
library(splancs)
library(mapproj)
library(Matrix)
library(parallel)
library(emulator)
library(splancs)
library(geosphere)
rm(list = ls())

inverse.stereo <- function(x,y,R=1){
  long0 = 0
  lat0 = -pi/2
  rho = sqrt( x^2 + y^2 )
  c = 2 * atan2( rho ,  2 * R )
  lat = asin( cos(c)*sin(lat0))
  long = long0 + atan2(x * sin(c), rho*cos(lat0)*cos(c) - y * sin(lat0)*sin(c) )
  res = cbind(long*180/pi,lat*180/pi)
  return(res)
}


load("final_reduced.RData")


####### ####### ####### ####### ####### ####### ####### 
####### Some functions for inference
####### ####### ####### ####### ####### ####### ####### 

inv_logit_all = function(x,lims = rho_lims){
  lims[,1] + (lims[,2] - lims[,1]) / (1 + exp(-x))
}

inv_logit = function(x,lims){
  lims[1] + (lims[2] - lims[1])/ ( 1 + exp(-x))
}



crit_depth_func = function(alp,k,rho,SMB){
  
  log_rho1 = log(rho[1] / (rho_i - rho[1]))
  log_rho2 = log(rho[2] / (rho_i - rho[2]))
  log_rho3 = log(rho[3] / (rho_i - rho[3]))
  
  kap1 = (log_rho1 - alp) / (rho_i * k[1])
  kap2 = kap1 + sqrt(SMB) * (log_rho2 - log_rho1) / (rho_i * k[2])
  kap3 = kap2 + sqrt(SMB) * (log_rho3 - log_rho2) / (rho_i * k[3])
  
  c(kap1,kap2,kap3)
  
}

proj_func = function(X){
  X_use = as.matrix(X[,apply(X,2,function(q){any(q != 0)})])
  diag(nrow(X_use)) -  quad.tform(solve(crossprod(X_use) + 1e-3 * diag(ncol(X_use))),X_use) 
}

x_func = function(depth, cutoff,smb){
  
  rho_i * cbind(
    ifelse(depth < cutoff[1], depth,cutoff[1] ),
    ifelse(depth < cutoff[2], depth - cutoff[1],
           cutoff[2] - cutoff[1]) * (depth > cutoff[1]) / sqrt(smb),
    ifelse(depth < cutoff[3], depth - cutoff[2],
           cutoff[3] - cutoff[2]) * (depth > cutoff[2]) / sqrt(smb),
    (depth - cutoff[3]) * (depth > cutoff[3]) / sqrt(smb)
  )
  
}


core_idx = lapply(1:57,function(x){which(dat_use$core == x)})

ni = sapply(core_idx,length)
reps_use = 10000
idx_use = 1:reps_use

projxy = mapproject(locs_unique[,1],locs_unique[,2],
                    projection = "stereographic",
                    orientation = c(-90,0,0))


pred_core1 = vector(mode = "list", length = n_u) 
pred_core2 = vector(mode = "list", length = n_u)


pars_now = apply(spat_pars[idx_use,,],c(2,3),mean)
bet_poly_now = apply(bet_poly[idx_use,,],c(2,3),mean)
bet_poly_cand = apply(bet_poly[idx_use,,],c(2,3),mean)

# 
# pars_now = spat_pars[reps+burn,,]
# bet_poly_now = bet_poly[reps+burn,,]

for(j in 1:n_u){
  
  idx = j


  
  cand = pars_now[idx,]
  k_cand = exp(cand[2:5] - exp(cand[6:9])/ (R_const * core_temp$temp10[idx]))
  
  rho_cand = inv_logit_all(cand[10:12],rho_lims)
  crit_depth_cand = crit_depth_func(cand[1],k_cand,rho_cand,core_temp$smb[idx])
  
  X_cand = lapply(core_loc_ind[[idx]],function(k){
    x_func(depth_list[[k]],crit_depth_cand,core_temp$smb[idx])
  })
  
  proj_X_cand = lapply(X_cand, proj_func)
  
  Z_cand = lapply(1:core_loc_ind_length[idx],function(k){
    proj_X_cand[[k]] %*% Z_raw[[core_loc_ind[[idx]][k]]]
  })
  
  
  mu_cand[core_loc_ind[[idx]]] = lapply(1:core_loc_ind_length[idx],function(k){
    c(rho_i * inv.logit(cand[1] + X_cand[[k]] %*% k_cand ))
  })
  
  tmep = lapply(1:core_loc_ind_length[idx],function(k){
    cand[1] + X_cand[[k]] %*% k_cand 
  })
  
  pred_core1[[j]] = mu_cand[core_loc_ind[[idx]]][[core_loc_ind_length[idx]]]
  
  
  mu_cand[core_loc_ind[[idx]]] = lapply(1:core_loc_ind_length[idx],function(k){
    c(rho_i * inv.logit(cand[1] + X_cand[[k]] %*% k_cand +
                          Z_cand[[k]] %*% bet_poly_cand[dat$loc_ind[core_loc_ind[[idx]][k]],]))
  })
  
  
  pred_core2[[j]] = mu_cand[core_loc_ind[[idx]]][[core_loc_ind_length[idx]]]
  
}


# 
# j= 14
# 
# int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))
# 
# plot(depth_list[[j ]],y_list[[j]],xlab = "depth",ylab = "Density (g/cm^3)",
#      xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.625))
# lines(c(0,depth_list[[j]]),c(int,pred_core1[[j]]),col = "green")
# lines(c(0,depth_list[[j]]),c(int,pred_core2[[j]]),col = "red")
# 
# j= 12
# 
# int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))
# 
# plot(depth_list[[j ]],y_list[[j]],xlab = "depth",ylab = "Density (g/cm^3)",
#      xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.625))
# lines(c(0,depth_list[[j]]),c(int,pred_core1[[j]]),col = "green")
# lines(c(0,depth_list[[j]]),c(int,pred_core2[[j]]),col = "red")
# 
# 
# j= 13
# 
# int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))
# 
# plot(depth_list[[j ]],y_list[[j]],xlab = "depth",ylab = "Density (g/cm^3)",
#      xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.625))
# lines(c(0,depth_list[[j]]),c(int,pred_core1[[j]]),col = "green")
# lines(c(0,depth_list[[j]]),c(int,pred_core2[[j]]),col = "red")
# 
# 
# 
# j= 25
# 
# int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))
# 
# plot(depth_list[[j ]],y_list[[j]],xlab = "depth",ylab = "Density (g/cm^3)",
#      xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.9))
# lines(c(0,depth_list[[j]]),c(int,pred_core1[[11]]),col = "green")
# lines(c(0,depth_list[[j]]),c(int,pred_core2[[11]]),col = "red")
# 
# j= 43
# 
# int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))
# 
# plot(depth_list[[j ]],y_list[[j]],xlab = "depth",ylab = "Density (g/cm^3)",
#      xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.9))
# lines(c(0,depth_list[[j]]),c(int,pred_core1[[j-1]]),col = "green")
# lines(c(0,depth_list[[j]]),c(int,pred_core2[[j-1]]),col = "red")
# 
# j= 36
# 
# int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))
# 
# plot(depth_list[[j ]],y_list[[j]],xlab = "depth",ylab = "Density (g/cm^3)",
#      xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.9))
# lines(c(0,depth_list[[j]]),c(int,pred_core1[[j-1]]),col = "green")
# lines(c(0,depth_list[[j]]),c(int,pred_core2[[j-1]]),col = "red")

pred_herron_langway = function(x,rho_0,temp,smb){
  
  n = length(x)
  k0 = 11 * exp(-10160 / (8.314 * temp))
  k1 = 575 * exp(-21400 / (8.314 * temp))
  crit_x = 1/(rho_i * k0) * (log(0.55/(rho_i - 0.55)) - log(rho_0/(rho_i - rho_0)))
  logit_pred = ifelse(x < crit_x, 
                      rho_i * k0 * x  + log(rho_0/(rho_i - rho_0)),
                      rho_i * k1 * (x - crit_x) / sqrt(smb) + log(0.55/(rho_i - 0.55))
  )
  
  rho_i * inv.logit(logit_pred)
  
}

# loc_use = 42
# x = seq(0,140,length = 1000)
# temp = temp_at_cores[loc_use]
# smb = smb_at_cores[loc_use]
# rho_0 = 0.38
# dens_pred = pred_herron_langway(x,rho_0,temp,smb)
# plot(dat_use$Depth[dat_use$loc_ind == loc_use],dat_use$Density[dat_use$loc_ind == loc_use],ylim = c(0.3,0.92))
# lines(x,dens_pred,col = "red",lwd = 2,lty = 2)
# abline(h = rho_i,col = "green",lwd = 2,lty = 3)

herron_miss = vector(mode = 'list',length = ns)


for(i in 1:ns){
  x = c(0,dat_use$Depth[dat_use$core == i])
  temp = core_temp$temp10[dat$loc_ind[i]]
  smb = core_temp$smb[dat$loc_ind[i]]
  rho_0 = lm(Density ~ Depth,data = dat_use[dat_use$core == i & 
                                              dat_use$Density < 0.55 & 
                                              dat_use$Depth < 25 , ])$coefficients[1]
  dens_pred = pred_herron_langway(x,rho_0,temp,smb)
  
  out = cbind(x,
              c(dens_pred[1],dat_use$Density[dat_use$core == i]),
              dens_pred,
              dens_pred - c(dens_pred[1],dat_use$Density[dat_use$core == i]))
  colnames(out) = c("Depth","Observed","Predicted","Difference")
  
  herron_miss[[i]] = out
  
  # plot(dat_use$Depth[dat_use$core == i],dat_use$Density[dat_use$core == i],ylim = c(0.3,0.92))
  # lines(x,dens_pred,col = "red",lwd = 2,lty = 2)
  # abline(h = rho_i,col = "green",lwd = 2,lty = 3)
  
}

herron_plot = function(i){
  
  plot(herron_miss[[i]][,"Depth"],herron_miss[[i]][,"Observed"])
  lines(herron_miss[[i]][,"Depth"],herron_miss[[i]][,"Predicted"],col = "red")
}



j= 4 ### site 8

int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))

# pdf("../../writing/fit_4.pdf")
par(mar = c(5,5,1,1))

plot(depth_list[[j ]],y_list[[j]],xlab = "Depth (m)", ylab = expression(paste("Density (g/",cm^3,")")),
     xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.95),pch = 20,cex.lab = 1.4)
lines(c(0,depth_list[[j]]),c(int,pred_core1[[j]]),
      col = "cyan",lwd = 4,lty = 1)
lines(c(0,depth_list[[j]]),c(int,pred_core2[[j]]),
      col = "red",lwd = 4,lty = 2)
lines(herron_miss[[j]][,"Depth"],herron_miss[[j]][,"Predicted"],
      col = "magenta3",lwd = 5,lty = 4)

legend("bottomright",c("Piecewise Arrhenius","Smoothed Arrhenius","Herron-Langway"),
       col = c("cyan","red","magenta3"),lwd = c(3,3,3),lty = c(1,2,4),cex = 2 )

# dev.off()



j= 8  ### site 8

int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))

# pdf("../../writing/fit_8.pdf")
par(mar = c(5,5,1,1))

plot(depth_list[[j ]],y_list[[j]],xlab = "Depth (m)", ylab = expression(paste("Density (g/",cm^3,")")),
     xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.95),pch = 20,cex.lab = 1.4)
lines(c(0,depth_list[[j]]),c(int,pred_core1[[j]]),
      col = "cyan",lwd = 4,lty = 1)
lines(c(0,depth_list[[j]]),c(int,pred_core2[[j]]),
      col = "red",lwd = 4,lty = 2)
lines(herron_miss[[j]][,"Depth"],herron_miss[[j]][,"Predicted"],
      col = "magenta3",lwd = 5,lty = 4)

legend("bottomright",c("Piecewise Arrhenius","Smoothed Arrhenius","Herron-Langway"),
       col = c("cyan","red","magenta3"),lwd = c(3,3,3),lty = c(1,2,4),cex = 2 )

# dev.off()

j= 12  ### site 13

int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))

# pdf("../../writing/fit_12.pdf")
par(mar = c(5,5,1,1))

plot(depth_list[[j ]],y_list[[j]],xlab = "Depth (m)", ylab = expression(paste("Density (g/",cm^3,")")),
     xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.625),pch = 20,cex.lab = 1.4)
lines(c(0,depth_list[[j]]),c(int,pred_core1[[j]]),
      col = "cyan",lwd = 4,lty = 1)
lines(c(0,depth_list[[j]]),c(int,pred_core2[[j]]),
      col = "red",lwd = 4,lty = 2)
lines(herron_miss[[j]][,"Depth"],herron_miss[[j]][,"Predicted"],
      col = "magenta3",lwd = 5,lty = 4)

legend("bottomright",c("Piecewise Arrhenius","Smoothed Arrhenius","Herron-Langway"),
       col = c("cyan","red","magenta3"),lwd = c(3,3,3),lty = c(1,2,4),cex = 2 )
# dev.off()



j= 50  ### site 48

int = rho_i * exp(pars_now[j-1,1])/(1 + exp(pars_now[j-1,1]))

# pdf("../../writing/fit_50.pdf")
par(mar = c(5,5,1,1))

plot(depth_list[[j ]],y_list[[j]],xlab = "Depth (m)", ylab = expression(paste("Density (g/",cm^3,")")),
     xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.9),pch = 20,cex.lab = 1.4)
lines(c(0,depth_list[[j]]),c(int,pred_core1[[j-1]]),
      col = "cyan",lwd = 4,lty = 1)
lines(c(0,depth_list[[j]]),c(int,pred_core2[[j-1]]),
      col = "red",lwd = 4,lty = 2)
lines(c(0,depth_list[[j]]),herron_miss[[j]][,"Predicted"],
      col = "magenta3",lwd = 5,lty = 4)

legend("bottomright",c("Piecewise Arrhenius","Smoothed Arrhenius","Herron-Langway"),
       col = c("cyan","red","magenta3"),lwd = c(3,3,3),lty = c(1,2,4),cex = 2 )

# dev.off()








j= 4 ### site 8

int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))

# pdf("../../writing/fit4.pdf")
par(mar = c(5,5,1,1))

plot(depth_list[[j ]],y_list[[j]],xlab = "Depth (m)", ylab = expression(paste("Density (g/",cm^3,")")),
     xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.95),pch = 20,cex.lab = 1.4)
lines(herron_miss[[j]][,"Depth"],herron_miss[[j]][,"Predicted"],
      col = "magenta3",lwd = 5,lty = 4)


# dev.off()



j= 8  ### site 8

int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))

# pdf("../../writing/fit8.pdf")
par(mar = c(5,5,1,1))

plot(depth_list[[j ]],y_list[[j]],xlab = "Depth (m)", ylab = expression(paste("Density (g/",cm^3,")")),
     xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.95),pch = 20,cex.lab = 1.4)

lines(herron_miss[[j]][,"Depth"],herron_miss[[j]][,"Predicted"],
      col = "magenta3",lwd = 5,lty = 4)


# dev.off()

j= 12  ### site 13

int = rho_i * exp(pars_now[j,1])/(1 + exp(pars_now[j,1]))

# pdf("../../writing/fit12.pdf")
par(mar = c(5,5,1,1))

plot(depth_list[[j ]],y_list[[j]],xlab = "Depth (m)", ylab = expression(paste("Density (g/",cm^3,")")),
     xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.625),pch = 20,cex.lab = 1.4)

lines(herron_miss[[j]][,"Depth"],herron_miss[[j]][,"Predicted"],
      col = "magenta3",lwd = 5,lty = 4)

# dev.off()



j= 50  ### site 48

int = rho_i * exp(pars_now[j-1,1])/(1 + exp(pars_now[j-1,1]))

# pdf("../../writing/fit50.pdf")
par(mar = c(5,5,1,1))

plot(depth_list[[j ]],y_list[[j]],xlab = "Depth (m)", ylab = expression(paste("Density (g/",cm^3,")")),
     xlim = c(0,max(depth_list[[j]])),ylim = c(int,0.9),pch = 20,cex.lab = 1.4)

lines(c(0,depth_list[[j]]),herron_miss[[j]][,"Predicted"],
      col = "magenta3",lwd = 5,lty = 4)


# dev.off()




