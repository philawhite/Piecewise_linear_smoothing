library(ggplot2)
library(dplyr)
library(boot)
library(maps)
library(mapdata)
library(fields)
library(splancs)
library(mapproj)
library(Matrix)
library(parallel)
library(emulator)
library(splancs)
library(geosphere)

##################### Stereographic to Mercator

inverse.stereo <- function(x,y,R=1){
  long0 = 0
  lat0 = -pi/2
  rho = sqrt( x^2 + y^2 )
  c = 2 * atan2( rho ,  2 * R )
  lat = asin( cos(c)*sin(lat0))
  long = long0 + atan2(x * sin(c), rho*cos(lat0)*cos(c) - y * sin(lat0)*sin(c) )
  res = cbind(long*180/pi,lat*180/pi)
  return(res)
}

###############################################################
### load in final workspace
###############################################################
load("final_reduced.RData")

###############################################################
### Thin correctly
#############################################################

core_idx = lapply(1:57,function(x){which(dat_use$core == x)})
reps_use = 1e4
idx_use = 1:reps_use

###############################################################
### Create grid over convex hull
#############################################################

projxy = mapproject(locs_unique[,1],locs_unique[,2],
                    projection = "stereographic",
                    orientation = c(-90,0,0))

con_hull = chull(projxy$x,projxy$y)
poly_out = cbind(projxy$x[con_hull],projxy$y[con_hull])

griddy = gridpts(poly_out,50^2)

plot(griddy,pch = 20)

n_grid = nrow(griddy)

griddy = cbind(griddy,inverse.stereo(griddy[,1],griddy[,2]))
colnames(griddy) = c("projx","projy","lon","lat")

###############################################################
### calculate distance matrices
#############################################################

dg = distm(griddy[,3:4],locs_unique,fun = distCosine) / 1000
gg = distm(griddy[,3:4],fun = distCosine) / 1000

###############################################################
### spatial predition
#############################################################

pred_spat = array(0,c(reps_use,n_grid,n_par))


st = proc.time()

###############################################################
### spatially interpolate parameters 
#############################################################

for(i in 1:reps_use){
  
  pars_now = spat_pars[idx_use[i],,]
  bet_poly_now = bet_poly[idx_use[i],,]
  
  V_now = V[idx_use[i],,]
  phi_now = phi[idx_use[i]]
  
  alp_now = alp[idx_use[i]]
  log_A_now = log_A[idx_use[i],]
  log_E_now = log_E[idx_use[i],]
  logit_rho_now = logit_rho_crit[idx_use[i],]
  
  mu_tot = c(alp_now,log_A_now,log_E_now,logit_rho_now)
  
  
  R = exp(- phi_now * dd)
  R_gd = exp(- phi_now * dg)
  R_gg = exp(- phi_now * gg)
  
  R_inv = solve(R)
  
  proj = R_gd %*% R_inv
  
  spat_cov = R_gg - proj %*% t(R_gd)
  
  chol_V = t(chol(V_now))
  chol_spat = t(chol(spat_cov))
  
  
  center_par = sweep(pars_now,2,mu_tot)
  
  pred_mean = c(sweep(apply(center_par,2,function(x){
    proj %*% x
  }),2,mu_tot,FUN = "+"))
  
  pred_spat[i,,] = matrix(pred_mean + (chol_V %x% chol_spat) %*% rnorm(n_par * n_grid),
                          n_grid,n_par)
  
  
  cat("\r", i, " of ", reps_use)
  flush.console()
  
  
}

###############################################################
### save only predictions
#############################################################

rm(list = setdiff(ls(),c("pred_spat","griddy")))

#save.image("pred_pars.RData")

